import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Variable } from '@angular/compiler/src/render3/r3_ast';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'
import { IssueService } from '../issue.service';
import { IUser } from '../user'



@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private issueService: IssueService) { }

  EmployeeForm = this.formBuilder.group(
    {
      // Add validations
      name: ['', Validators.required],
      lname: ['', Validators.required],
      id: ['', Validators.required],

    }
  );

  onSubmit() {
    console.log("Hello from onSubmit")
    // console.log(this.EmployeeForm.value.name)
    // console.log(this.EmployeeForm.value.id)
    // console.log(this.EmployeeForm.value.lname)

    const id = this.EmployeeForm.value.id
    const fname = this.EmployeeForm.value.name
    const lname = this.EmployeeForm.value.lname

    this.issueService.updateRec(id, fname, lname).subscribe(() => {
      console.log("successfull")
    })
    window.location.reload()   //use to reload data to show new updated values 
  }

  // updateRecord(id=2,firstName='sanket',lastName='ranawade')
  // {
  //   this.issueService.updateRec(id,firstName,lastName).subscribe(()=>{
  //     console.log("successfull")
  //   })
  // }

  // SetData()
  // {

  //   this.EmployeeForm.setValue(
  //     {
  //       name : 'sss',
  //       lname : 'abcd',
  //       id :  'abcd',

  //     }
  //   )
  // }


  //below method is use for setvalue function

  update(name, lname, id) {
    // console.log(id)
    // console.log(name)
    // console.log(lname)
    this.EmployeeForm.setValue(
      {
        name: name,
        lname: lname,
        id: id,

      }
    )
  }

//below method takes hardcoded parameter and delete the record
  //it calls the method written in service(deleteRec)
  deleteRecord(id) {
    this.issueService.deleteRec(id).subscribe(() => {
      console.log("deleted succesfully")
    });
    window.location.reload()
  }


  issues: IUser[]

  ngOnInit(): void {

    this.issueService.getdata().subscribe((res) => {
      this.issues = res;

      console.log(
        this.issues
      )
    })


  }

}
