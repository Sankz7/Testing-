import { Pipe, PipeTransform } from '@angular/core';
import { IUser } from './user'



@Pipe({
  name: 'searchfilter'
})
export class SearchfilterPipe implements PipeTransform {

  transform(items:IUser[], searchText: string): IUser[] {
    if(!items || !searchText)
    {
    return items;
    }
    
    return items.filter( items => 
      items.firstName.includes(searchText))
  }

  }
