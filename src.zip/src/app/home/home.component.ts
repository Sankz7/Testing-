import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { IssueService } from '../issue.service';
import { IUser } from '../user'


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public id:any;
  public name:any;
  
  public zipcode:any;
  public zip = [94587, 98231]
  

  constructor(private issueService: IssueService) { }


 

  display(userform: NgForm)
  {
    // this.id = userform.value.Id
    // this.name = userform.value.Name
    // this.zipcode = userform.value.Zips
    // console.log(this.id)
    
    // console.log(this.zipcode)
  }

   issues: IUser[]
   searchText:string;

  ngOnInit() {


    this.issueService.getdata().subscribe((res) => {
      this.issues = res;

      console.log(
        this.issues
      )
      
    })
    //this.addrec()
  }

}
