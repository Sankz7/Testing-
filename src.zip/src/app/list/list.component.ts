import { Component, OnInit, ɵConsole } from '@angular/core';
import { IssueService } from '../issue.service';
import { IUser } from '../user'
import { from } from 'rxjs';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {


  constructor(private issueService: IssueService) { }

  showSuccessMessage: boolean;

  saveEmployee(empform: NgForm) {
    // console.log(empform.value);
    // console.log(empform.value.Name);
    // console.log(empform.value.LastName);
    // console.log(empform.value.Id);

    const Fname = empform.value.Name
    const Lname = empform.value.LastName
    const id = empform.value.Id

    this.addRecord(id, Fname, Lname) //passing values to addRecord method 

    empform.reset();   // use to empty fields in form after submit

    this.showSuccessMessage = true;
    setTimeout(() => this.showSuccessMessage = false, 8000);
  }











  //below method takes hardcoded parameter and insert the records
  //it calls the method written in service(addRec)

  addRecord(id, Fname, Lname) {
    this.issueService.addRec(id, Fname, Lname).subscribe(() => {
      console.log("successfull")
    })
    window.location.reload()
  }

  
 




  issues: IUser[]

  ngOnInit() {


    this.issueService.getdata().subscribe((res) => {
      this.issues = res;

      console.log(
        this.issues
      )
    })
    //this.addrec()
  }

}
